struct FBSignupResponseBody
{
    // none
    // using header.status

}



