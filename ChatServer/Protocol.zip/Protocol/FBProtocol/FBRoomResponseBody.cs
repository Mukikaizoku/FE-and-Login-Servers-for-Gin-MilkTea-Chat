
namespace ChatServer
{
    struct FBRoomResponseBody
    {
        byte[] data;// data can be : chat Room List, FE IP-PORT, chat room no 
    }
}