

namespace ChatServer
{
    struct CFRoomResponseBody
    {
        byte[] data;
        // data -> roomNo, IP, Port, timeStamp, chatRoom List 

    }
}