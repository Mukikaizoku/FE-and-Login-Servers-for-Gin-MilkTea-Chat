﻿
namespace ChatServer
{
    struct ConnectionPassResponseBody
    {
        //none
    }
}
