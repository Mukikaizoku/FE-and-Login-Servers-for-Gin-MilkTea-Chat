struct CFSignupResponseBody{
  // none 
}
